double llenarMaletaPar(double w[], double v[], int z[], int n, double maxW,
                       int k);
double llenarMaletaSec(double w[], double v[], int z[], int n, double maxW,
                       int k);
