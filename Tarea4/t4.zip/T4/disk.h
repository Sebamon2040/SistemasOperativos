void iniDisk(void);
void cleanDisk(void);
void requestDisk(int track);
void releaseDisk(void);
