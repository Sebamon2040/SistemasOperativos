#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "pss.h"
#include "bolsa.h"
#include "spinlocks.h"

// Declare aca sus variables globales

int vendo(int precio, char *vendedor, char *comprador) {
  ...
}

int compro(char *comprador, char *vendedor) {
  ...
}
